package com.resultcopy.rest.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import java.util.List;

public class PatientResultTest {
 PatientResult patientResult = new PatientResult();
  @Mock
  List<Patient> patientList;
  @Mock
  Patient patient;
  @Mock
  List<Child> child;
  @Mock
  List<Category> category;

    /**
     * Test for setter method of PatientList.
     */
  @Test
    public void testPatientList(){
      patientResult.setPatient(patientList);
      Assertions.assertEquals(patientList,patientResult.getPatient());
  }

    /**
     * Test for setter method of Patient.
     */
    @Test
    public void testPatient(){
        patientResult.setPatientt(patient);
        Assertions.assertEquals(patientList,patientResult.getPatientt());
    }

    /**
     * Test for setter method of child.
     */
    @Test
    public void testChild(){
        patientResult.setChild(child);
        Assertions.assertEquals(child,patientResult.getChild());
    }

    /**
     * Test for setter method of category.
     */
    @Test
    public void testCategory(){
        patientResult.setCategory(category);
        Assertions.assertEquals(category,patientResult.getCategory());
    }

    /**
     * Test for PatientListConstructor.
     */
    @Test
    public void testPatientListConstructor(){
        Assertions.assertNotNull(patientResult.patient(patientList));
    }

    /**
     * Test for ChildList constructor.
     */
    @Test
    public void testChildListConstructor(){
        Assertions.assertNotNull(patientResult.child(child));
    }

    /**
     * Test for category constructor.
     */
    @Test
    public void testCategoryConstructor(){
        Assertions.assertNotNull(patientResult.category(category));
    }

    /**
     * Test for toString method
     */
    @Test
    public void testToStringReturnString(){
        Assertions.assertEquals(patientResult.toString(), "class PatientResult {\n" +
                "    patient: null\n" +
                "    patient: []\n" +
                "    child: []\n" +
                "    category: []\n" +
                "}");
    }

    /**
     * Test for hashCode method.
     */
    @Test
    public void testHashCode()
    {
        Assertions.assertNotEquals(12345, patientResult.hashCode());
    }

    /**
     * Test for equals method.
     */
    @Test
    public void testPatientDetailsEquals()
    {
        Assertions.assertEquals(false, patientResult.equals(0));
        Assertions.assertEquals(true, patientResult.equals(patientResult));
        PatientResult patientResultDetails = new PatientResult();
        Assertions.assertEquals(false,patientResultDetails.equals(patientResult));
    }
}
