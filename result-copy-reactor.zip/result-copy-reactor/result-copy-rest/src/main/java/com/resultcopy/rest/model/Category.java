package com.resultcopy.rest.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

/**
 * List of categories available as a part of patient reports.
 */
@Schema(description = "List of categories available as a part of patient reports.")
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")public class Category   {
  @JsonProperty("id")
  private Integer id = null;

  @JsonProperty("displayName")
  private String displayName = null;

  @JsonProperty("result")
  private List<Result> result = null;

  /**
   * Constructor for category id.
   * @param id {@link Category} Unique identifier for a category.
   * @return id {@link Category} Returns the Identifier for category.
   */
  public Category id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Unique identifier for category.
   * @return id {@link Category} Returns the identifier set for category.
   */
  @JsonProperty("id")
  @Schema(example = "20", description = "Identifier for category.")
  public Integer getId() {
    return id;
  }

  /**
   * Setter for Category Identifier.
   * @param id {@link Category} Unique identifier for category.
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * Constructor for displayName of Category.
   * @param displayName {@link Category} It is the name of the category.
   * @return The displayName is returned.
   */
  public Category displayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

  /**
   * Getter method for displayName of Category.
   * Name of the category.
   * @return displayName {@link Category}The name of the category is returned.
   */
  @JsonProperty("displayName")
  @Schema(example = "DELIVERY_INFORMATION", description = "Name of the category.")
  public String getDisplayName() {
    return displayName;
  }

  /**
   * Setter method for displayName of category.
   * @param displayName This is the name of the category.
   */
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   * Constructor for result.
   * @param result Sets the result for category.
   * @return Returns the result set for category.
   */
  public Category result(List<Result> result) {
    this.result = result;
    return this;
  }

  /**
   * List of result details documented for the mother patient.
   * @return result. The result details for category is returned.
   */
  @JsonProperty("result")
  @Schema(description = "List of result details documented for the mother patient.")
  @Valid
  public List<Result> getResult() {
    return result;
  }

  /**
   * Setter method for list of result.
   * @param result The result details for category.
   */
  public void setResult(List<Result> result) {
    this.result = result;
  }

  /**
   * Checks for object equalization.
   * @param object generated the object of babyResult.
   * @return boolean value on bject equality.
   */
  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null || getClass() != object.getClass()) {
      return false;
    }
    Category category = (Category) object;
    return Objects.equals(this.id, category.id) &&
        Objects.equals(this.displayName, category.displayName) &&
        Objects.equals(this.result, category.result);
  }

  /**
   * Hash code method.
   * @return overriding hashcode.
   */
  @Override
  public int hashCode() {
    return Objects.hash(id, displayName, result);
  }


  /**
   * To string method.
   * @return to string method returns the string format of baby Result.
   */
  @Override
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("class Category {\n");
    stringBuilder.append("    id: ").append(toIndentedString(id)).append("\n");
    stringBuilder.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    stringBuilder.append("    result: ").append(toIndentedString(result)).append("\n");
    stringBuilder.append("}");
    return stringBuilder.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object object) {
    if (object == null) {
      return "null";
    }
    return object.toString().replace("\n", "\n    ");
  }
}
