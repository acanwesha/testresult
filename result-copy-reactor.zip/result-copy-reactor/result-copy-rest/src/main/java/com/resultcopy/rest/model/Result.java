package com.resultcopy.rest.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Objects;

/**
 * List of result details documented for the mother patient.
 */
@Schema(description = "List of result details documented for the mother patient.")
@JsonInclude(JsonInclude.Include.NON_NULL)
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")public class Result   {
  @JsonProperty("id")
  private Integer id = null;

  @JsonProperty("displayName")
  private String displayName = null;

  @JsonProperty("value")
  private String value = null;

  /**
   * Constructor for unique identifier for result.
   * @param id {@link Result} Unique identifier for result.
   * @return Unique identifier for result is returned.
   */
  public Result id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Identifier for result.
   * @return id unique identifier.
   */
  @JsonProperty("id")
  @Schema(example = "20", description = "Identifier for result.")
  public Integer getId() {
    return id;
  }

  /**
   * Sets the unique identifier for result.
   * @param id sets the unique identifier for the result.
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * Constructor for displayName.
   * @param displayName name of result
   * @return displayName set.
   */
  public Result displayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

  /**
   * The result name for a particular category.
   * @return displayName The displayName of result is returned.
   **/
  @JsonProperty("displayName")
  @Schema(example = "PREGNANCY_OUTCOME", description = "The result name for a particular category.")
  public String getDisplayName() {
    return displayName;
  }

  /**
   * Sets the display name for result.
   * @param displayName sets the display name of result.
   */
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   * Constructor for value associated with result.
   * @param value constructor for result value.
   * @return value set.
   */
  public Result value(String value) {
    this.value = value;
    return this;
  }

  /**
   * The value associated with the result for the patient.
   * @return value Value associated with result is returned.
   */
  @JsonProperty("value")
  @Schema(example = "VAGINAL_BIRTH", description = "The value associated with the result for the patient.")
  public String getValue() {
    return value;
  }

  /**
   * Sets the value associated with result.
   * @param value sets the value for a particular result.
   */
  public void setValue(String value) {
    this.value = value;
  }

  /**
   * Method to check object equality.
   * @param object object.hash of Result.
   * @return object. object generated for class.
   */
  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null || getClass() != object.getClass()) {
      return false;
    }
    Result result = (Result) object;
    return Objects.equals(this.id, result.id) &&
        Objects.equals(this.displayName, result.displayName) &&
        Objects.equals(this.value, result.value);
  }

  /**
   * hash code method
   * @return object.hash of result.
   */
  @Override
  public int hashCode() {
    return Objects.hash(id, displayName, value);
  }

  /**
   * toString method
   * @return Converts the given Result object to string.
   */
  @Override
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("class Result {\n");
    
    stringBuilder.append("    id: ").append(toIndentedString(id)).append("\n");
    stringBuilder.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    stringBuilder.append("    value: ").append(toIndentedString(value)).append("\n");
    stringBuilder.append("}");
    return stringBuilder.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
