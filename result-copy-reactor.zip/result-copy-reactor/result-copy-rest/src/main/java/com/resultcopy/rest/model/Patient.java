package com.resultcopy.rest.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;

/**
 * Information about the patient.
 */
@Schema(description = "Information about the patient.")
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")public class Patient   {
  @JsonProperty("patientDetails")
  private PatientDetails patientDetails = null;

  /**
   * Initializes the patient details.
   * @param patientDetails {@link PatientDetails}
   * @return {@link Patient} returns the details for a patient.
   */
  public Patient patientDetails(PatientDetails patientDetails) {
    this.patientDetails = patientDetails;
    return this;
  }

  /**
   * Information about the patient.
   * @return patientDetails {@link PatientDetails} returns the details for a patient.
   */
  @JsonProperty("patientDetails")
  @Schema(description = "Information about the patient.")
  @Valid
  public PatientDetails getPatientDetails() {
    return patientDetails;
  }

  /**
   * Sets the details for a particular patient.
   * @param patientDetails sets the details of a patient.
   */
  public void setPatientDetails(PatientDetails patientDetails) {
    this.patientDetails = patientDetails;
  }

  /**
   * Convert the given patient object to string.
   */
  @Override
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("class Patient {\n");

    stringBuilder.append("    patientDetails: ").append(toIndentedString(patientDetails)).append("\n");
    stringBuilder.append("}");
    return stringBuilder.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object object) {
    if (object == null) {
      return "null";
    }
    return object.toString().replace("\n", "\n    ");
  }
}
