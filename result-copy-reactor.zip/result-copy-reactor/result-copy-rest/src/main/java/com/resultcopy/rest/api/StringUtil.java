package com.resultcopy.rest.api;

/**
 * This class is used for String manipulations.
 */
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")
public class StringUtil {

  /**
   * Check if the given array contains the given value (with case-insensitive comparison).
   * @param array The array to check the case of the string.
   * @param value The value to search.
   * @return true if the array contains the value.
   */
  public static boolean containsIgnoreCase(String[] array, String value) {
    for (String str : array) {
      if (value == null && str == null) return true;
      if (value != null && value.equalsIgnoreCase(str)) return true;
    }
    return false;
  }

  /**
   * Join an array of strings with the given separator.
   * <p>Note: This might be replaced by utility method from commons-lang or guava someday if one of
   * those libraries is added as dependency.
   * @param array The array of strings.
   * @param separator The separator.
   * @return the resulting string.
   */
  public static String join(String[] array, String separator) {
    int len = array.length;
    if (len == 0) return "";
    StringBuilder out = new StringBuilder();
    out.append(array[0]);
    for (int i = 1; i < len; i++) {
      out.append(separator).append(array[i]);
    }
    return out.toString();
  }
}
