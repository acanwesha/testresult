package com.resultcopy.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.resultcopy.PatientDetailsResponse;
import com.resultcopy.PatientResponse;
import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.PatientDAO;

/**
 * @author AC089545
 * The method returns the patient details.
 */
public class PatientDAOImpl implements PatientDAO {
    private Connection connection = null;

    /**
     * Constructor to set the connect for database.
     * @param connection {@link Connection} The databse connection object is set.
     */
    public PatientDAOImpl(Connection connection) {
        this.connection = connection;
    }

    /**
     * The database connection object is set.
     */
    public PatientDAOImpl() {
        this.connection = ConnectionFactory.getConnection();
    }

    /**
     * The patient details are returned.
     * @param patientId {@link PatientDAO} Unique Identifier for a patient.
     * @return The details of a particular patient is returned.
     * @throws RuntimeException Throws Exception when patient details are not found.
     */
    @Override
    public PatientResponse getPatientById(Integer patientId) throws RuntimeException {
        PatientResponse patient = null;
        PatientDetailsResponse patientDetailsResponse = null;
        String sql = " SELECT * FROM patient WHERE PATIENT_ID =  "+patientId;
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                if(resultSet.wasNull())
                {
                    throw new RuntimeException("Patient Id not found");
                }
                patientDetailsResponse= new PatientDetailsResponse();
                patientDetailsResponse.setId(resultSet.getInt("PATIENT_ID"));
                patientDetailsResponse.setFirstName(resultSet.getString("FIRST_NAME"));
                patientDetailsResponse.setLastName(resultSet.getString("LAST_NAME"));
                patientDetailsResponse.setMrn(resultSet.getString("MRN"));
                patientDetailsResponse.setFin(resultSet.getString("FIN"));
            }
            patient = new PatientResponse();
            patient.setPatientDetails(patientDetailsResponse);
        }catch (SQLException exception){
            new RuntimeException("SQL Exception occured");
        }
        return patient;
    }
}
