package com.resultcopy.service.dao;

import com.resultcopy.ChildResultResponse;
import com.resultcopy.ResultResponse;
import java.util.List;

/**
 * @author AC089545
 * Interface ResultDAO containing the method to get the result details of a patient.
 */
public interface ResultDAO {

    /**
     * Result details for a particular category is returned.
     * @param categoryId {@link CategoryDAO} Unique Identifier for a category.
     * @return The result details for a particular category is returned.
     */
    public List<ResultResponse> getCategories(Integer categoryId);

    /**
     * The child Result for a particular patient is returned.
     * @param patientId {@link PatientDAO}
     * @return The child Result for a particular patient is returned.
     */
    public List<ChildResultResponse> getChildValueById(Integer patientId);
}
