package com.resultcopy.service.dao;

import com.resultcopy.PatientResponse;

/**
 * @author AC089545
 * Interface PatientDAO containing the method to get the patient details.
 */
public interface PatientDAO {

    /**
     * The method is declared to get the details of a Patient.
     * @param patientId {@link PatientDAO} Unique Identifier for a patient.
     * @return The details of the patient is returned.
     */
    PatientResponse getPatientById(Integer patientId);
}
